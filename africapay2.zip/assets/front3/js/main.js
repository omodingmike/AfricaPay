(function ($) {
	"use strict";

    jQuery(document).ready(function($){
        });




        /*--window Scroll functions--*/
        $(window).on('scroll', function () {
        
        });
           
/*--window load functions--*/
    jQuery(window).load(function(){
    });


}(jQuery));	